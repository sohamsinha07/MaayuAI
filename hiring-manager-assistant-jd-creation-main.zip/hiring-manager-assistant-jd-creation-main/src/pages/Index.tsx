
import JobCreator from "@/components/JobCreator";

const Index = () => {
  return <JobCreator />;
};

export default Index;
